# Adult Day Care Directory — Centennial & Aurora, CO

> **Home:** 6389 E Irwin Pl, Centennial, CO 80112
> **Destination:** Children's Hospital Colorado, 13123 E 16th Ave, Aurora, CO 80045
> **Generated:** 2026-03-11

## Group 1: Within 10 Miles of Home

| Facility | Address | Phone | Hours | New Patients | Private Pay | Distance | Confidence |
|----------|---------|-------|-------|:------------:|:-----------:|:--------:|:----------:|
| Mairik Adult Day Care | 7255 S. Havana St. Suite 130, Centennial, CO 80112 | (303) 736-2466 | Mon-Sat (call for specific hours) | Unknown | Unknown | 0.8 mi | HIGH |
| Someren Glen Adult Day Services | 5000 E. Arapahoe Rd., Centennial, CO 80122 | (303) 779-5000 | Mon-Fri, 9:00 AM - 4:00 PM | Unknown | Unknown | 2.8 mi | HIGH |
| Alpine Adult Day Care | 1985 S. Havana St., Aurora, CO 80014 | (303) 755-8002 | Mon-Fri, 8:00 AM - 4:00 PM | Y | Y | 4.5 mi | HIGH |
| Adult Day Care Services of Colorado | 15111 E. Hampden Ave., Aurora, CO 80014 | (720) 484-6143 | Mon-Fri, 8:00 AM - 3:00 PM | Unknown | Y | 5.2 mi | HIGH |
| Prestige Senior Social Club Adult Day Care | 2680 S. Havana St. Unit C, Aurora, CO 80014 | (720) 476-3898 | Mon-Fri, 8:00 AM - 5:00 PM | Unknown | Unknown | 4.5 mi | HIGH |
| Colorado Spirit Adult Day Care Services | 10610 E. Bethany Dr., Unit A, Aurora, CO 80014 | (303) 745-3344 | Call for hours | Unknown | Unknown | 5.8 mi | HIGH |
| Comfort Adult Day Care | 10691 E. Bethany Dr., Suite 900, Aurora, CO 80014 | (303) 632-6794 | Mon-Sat, 8:00 AM - 4:00 PM | Unknown | Y | 5.8 mi | MEDIUM |
| Hans Adult Daycare LLC | 911 S. Havana St., Suite A, Aurora, CO 80012 | (720) 641-5430 | Mon-Fri, 9:00 AM - 5:00 PM | Unknown | Y | 6.2 mi | HIGH |
| 2nd Home Community — Iliff | 10730 E. Iliff Ave., Aurora, CO 80014 | (720) 281-1536 | Mon-Fri, 8:00 AM - 4:00 PM | Unknown | Unknown | 5.5 mi | HIGH |
| 2nd Home Community — Peoria | 2990 S. Peoria St., Aurora, CO 80014 | (720) 281-1536 | Mon-Fri, 8:00 AM - 4:00 PM | Unknown | Unknown | 7.2 mi | HIGH |
| 2nd Home Community — Parker | 3138 S. Parker Rd., Aurora, CO 80014 | (720) 417-1261 | Mon-Fri, 8:00 AM - 4:30 PM | Unknown | Unknown | 7.0 mi | HIGH |
| 2nd Home Community — Abilene | 1200 S. Abilene St., Unit C, Aurora, CO 80012 | (720) 795-6140 | Mon-Fri, 8:00 AM - 4:00 PM | Unknown | Unknown | 8.2 mi | HIGH |
| Happy Living and Wellness Adult Daycare | 14015 E. Evans Ave., Aurora, CO 80014 | (720) 390-5697 | Mon-Fri, 7:30 AM - 2:30 PM | Unknown | Y | 6.3 mi | HIGH |
| Paradise Senior Daycare (Comport Paradise) | 5280 S. Jebel St., Aurora, CO 80015 | (720) 220-1377 | Mon-Sat, 8:00 AM - 4:00 PM | Unknown | Unknown | 7.8 mi | MEDIUM |
| Compassion Adult Daycare | 1740 S. Buckley Rd. #11, Aurora, CO 80017 | (720) 427-8977 | Mon-Fri, 8:00 AM - 4:00 PM | Unknown | Y | 8.5 mi | MEDIUM |
| Flatirons Adult Day Care | 15433 E. Hampden Ave., Suite D, Aurora, CO 80013 | (720) 536-8961 | Mon-Fri, 8:00 AM - 4:00 PM | Unknown | Unknown | 6.2 mi | HIGH |
| New Day In-Home and Respite Services | 20971 E. Smoky Hill Rd., Suite 101, Centennial, CO 80015 | (303) 841-1399 | Mon-Thu, 9:00 AM - 3:30 PM | Unknown | Y | 8.9 mi | HIGH |
| Johnson Adult Day Program | 3444 S. Emerson St., Englewood, CO 80113 | (800) 558-0653 | Call for hours | Unknown | Unknown | 9.5 mi | LOW |

## Group 2: I-225 Commute Corridor (Within 5 mi)

| Facility | Address | Phone | Hours | New Patients | Private Pay | Distance | Confidence |
|----------|---------|-------|-------|:------------:|:-----------:|:--------:|:----------:|
| Apex Adult Day Services | 562 Sable Blvd., Unit 150, Aurora, CO 80011 | (720) 449-2682 | Mon-Fri, 8:00 AM - 4:00 PM | Unknown | Unknown | 11.5 mi | HIGH |
| Venezia Innovative Services — Adult Day Program | 15343 E. 6th Ave., Aurora, CO 80011 | (303) 537-7078 | Mon-Fri, 8:30 AM - 6:00 PM | Unknown | Y | 12.5 mi | HIGH |
| InnovAge Colorado PACE Center — Aurora | 3551 N. Chambers Rd., Aurora, CO 80011 | (303) 502-9433 | Mon-Fri, 8:00 AM - 5:00 PM | Y | N | 12.8 mi | HIGH |
| Seniors' Choice Adult Day Program | 14280 E. Jewell Ave. #B, Aurora, CO 80012 | (303) 344-0046 | Mon-Thu, 8:00 AM - 6:00 PM | Unknown | Y | 9.5 mi | HIGH |
| World Wide Adult Day Care and Transportation | 10890 E. Dartmouth Ave., Unit I, Aurora, CO 80014 | (303) 815-6285 | Call for hours | Y | Unknown | 6.5 mi | MEDIUM |
| Aurora Adult Day Care LLC | 1330 S. Potomac St., Suite 118, Aurora, CO 80012 | (720) 484-5706 | Mon-Fri, 8:00 AM - 4:00 PM | Y | Unknown | 8.8 mi | HIGH |
| Everest Adult Day Care LLC | 12201 E. Mississippi Ave., Unit 101, Aurora, CO 80012 | (720) 612-7854 | Call for hours | Unknown | Unknown | 10.2 mi | MEDIUM |
| Relax Adult Day Care | 1042-1044 S. Peoria St., Aurora, CO 80012 | (303) 758-0871 | Mon-Fri, 8:00 AM - 5:00 PM (Fri until 4:30 PM) | Unknown | Unknown | 8.5 mi | LOW |
| BMH Corp. LLC | 13140 E. Mississippi Ave., Aurora, CO 80012 | (720) 282-3578 | Mon-Fri and Sun, 8:30 AM - 3:00 PM | Unknown | Unknown | 10.3 mi | LOW |

---
*MIT License | Generated by AEPT-AI*
